﻿using System;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace PsihologiTest
{
    public partial class Form3 : Form
    {
        SqlConnection sqlConnection;
        SqlDataReader sqlReader;
        public Form3()
        {
            InitializeComponent();
            string connection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Софья\Desktop\Проект\PsihologiTest\Database.mdf;Integrated Security=True";
            sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();
            sqlReader = null;
            var command = new SqlCommand("SELECT * FROM [Test]", sqlConnection);
            sqlReader = command.ExecuteReader();
        }
        int i = 1;
        public int res = 0;
        public int dop1 = 0; public int dop2 = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            if (sqlReader.Read())
            {
                label1.Text = sqlReader.GetString(1) + '\n' +
                              sqlReader.GetString(2) + '\n' +
                              sqlReader.GetString(3) + '\n' +
                              sqlReader.GetString(4) + '\n';
            }

            i++;
            if (i == 1 || i == 11 || i == 16)
            {
                if (radioButton1.Checked)
                {
                    res += 1;
                    dop1 += 1;
                }
                else if (radioButton2.Checked)
                {
                    res += 2;
                }
                else if (radioButton3.Checked)
                {
                    res += 3;
                    dop2 += 1;
                }
            }
            if (i == 2 || i == 7 || i == 8 || i == 19)
            {
                if (radioButton1.Checked)
                {
                    res += 2;
                }
                else if (radioButton2.Checked)
                {
                    res += 1;
                    dop1 += 1;
                }
                else if (radioButton3.Checked)
                {
                    res += 3;
                    dop2 += 1;
                }
            }
            if (i == 3 || i == 5 || i == 9 || i == 20)
            {
                if (radioButton1.Checked)
                {
                    res += 3;
                    dop2 += 1;
                }
                else if (radioButton2.Checked)
                {
                    res += 2;
                }
                else if (radioButton3.Checked)
                {
                    res += 1;
                    dop1 += 1;
                }
            }
            if (i == 4 || i == 6 || i == 9 || i == 14)
            {
                if (radioButton1.Checked)
                {
                    res += 2;
                }
                else if (radioButton2.Checked)
                {
                    res += 3;
                    dop2 += 1;
                }
                else if (radioButton3.Checked)
                {
                    res += 1;
                    dop1 += 1;
                }
            }
            if (i == 1 || i == 11 || i == 16)
            {
                if (radioButton1.Checked)
                {
                    res += 1;
                    dop1 += 1;
                }
                else if (radioButton2.Checked)
                {
                    res += 2;
                }
                else if (radioButton3.Checked)
                {
                    res += 3;
                    dop2 += 1;
                }
            }
            if (i == 10)
            {
                if (radioButton1.Checked)
                {
                    res += 3;
                    dop2 += 1;
                }
                else if (radioButton2.Checked)
                {
                    res += 1;
                    dop1 += 1;
                }
                else if (radioButton3.Checked)
                {
                    res += 2;
                }
            }
            if (i == 13 || i == 15 || i == 17 || i == 18)
            {
                if (radioButton1.Checked)
                {
                    res += 1;
                    dop1 += 1;
                }
                else if (radioButton2.Checked)
                {
                    res += 3;
                    dop2 += 1;
                }
                else if (radioButton3.Checked)
                {
                    res += 2;
                }
            }
            if (i == 19)
            {
                button1.Enabled = false;
                button1.Text = "Завершите тест -->";
                button2.Enabled = true;
                sqlReader.Close();
            }
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
            f4.label1.Text = res.ToString();
            if (dop2 >= 7 && dop1 <= 7)
            {
                f4.label3.Text = "Ваша агрессивность носит скорее разрушительный, " +
                    "чем конструктивный характер. Вы склон-ны к непродуманным поступкам " +
                    "и ожесточенным дискуссиям. Относитесь к людям пренебрежительно и своим " +
                    "поведением провоцируете конфликтные ситуации, которых вполне могли бы избежать.";
            }
            if (dop2 <= 7 && dop1 >= 7)
            {
                f4.label3.Text = "Вы чрезмерно замкнуты. Это не значит, " +
                    "что вам не присущи вспышки агрессивности, просто вы их тщательно подавляете.";
            }
            Close();
        }
    }
}
