﻿using System;
using System.Windows.Forms;

namespace PsihologiTest
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
